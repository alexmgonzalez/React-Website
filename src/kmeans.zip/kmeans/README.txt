*READ ME*

This is a simple k-means clustering algorithm

This program was written in python, while testing and debugging was done on zeus.cs.txstate. To execute, please run this command:

	python3 kmeans.py #(k) input.txt(points to input)

For example:

	python3 kmeans.py 2 input1.txt
