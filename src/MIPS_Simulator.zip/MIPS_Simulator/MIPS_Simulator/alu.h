//
//  alu.h
//  MIPS_Simulator
//
//  Created by Alex Gonzalez on 5/9/20.
//  Copyright © 2020 Alex Gonzalez. All rights reserved.
//

#include <string>

using namespace std;

class ALU{
private:
    string reg1;
    string reg2;
public:
    void setReg1(string);
    void setReg2(string);
};



